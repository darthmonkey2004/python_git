#!/bin/bash

pip3 install --user 'dist/python_git-1.0.tar.gz'
